﻿const API_BASE = '';

const $ = (sel) => document.querySelector(sel);
const gridBody = $('#gridBody');
const searchInput = $('#searchInput');

function fmtDate(iso) {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '';
    const y = d.getFullYear();
    const m = `${d.getMonth() + 1}`.padStart(2, '0');
    const da = `${d.getDate()}`.padStart(2, '0');
    return `${y}-${m}-${da}`;
}

function daysUntil(iso) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const d = new Date(iso);
    d.setHours(0, 0, 0, 0);
    const ms = d - today;
    return Math.ceil(ms / (1000 * 60 * 60 * 24));
}

async function loadMedicines() {
    const q = searchInput.value.trim();
    const url = q ? `/api/medicines?search=${encodeURIComponent(q)}` : '/api/medicines';
    const res = await fetch(API_BASE + url);
    const data = await res.json();
    renderGrid(data);
}

function renderGrid(items) {
    gridBody.innerHTML = '';
    for (const m of items) {
        const tr = document.createElement('tr');
        tr.classList.add('row');
        const days = daysUntil(m.expiryDate);
        if (days < 30) tr.classList.add('error');
        else if (m.quantity < 10) tr.classList.add('warn');

        tr.innerHTML = `
      <td>${m.fullName}</td>
      <td>${fmtDate(m.expiryDate)}</td>
      <td>${m.quantity}</td>
      <td>${Number(m.price).toFixed(2)}</td>
      <td>${m.brand}</td>
      <td>
        <button class="action-btn" data-id="${m.id}" data-name="${m.fullName}">Sell</button>
      </td>
    `;
        const btn = tr.querySelector('button');
        btn.addEventListener('click', async () => {
            const qtyStr = prompt(`Enter quantity to sell for "${m.fullName}":`, '1');
            if (!qtyStr) return;
            const qty = parseInt(qtyStr, 10);
            if (!Number.isFinite(qty) || qty <= 0) { alert('Enter a valid positive number'); return; }
            const resp = await fetch(API_BASE + '/api/sales', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ medicineId: m.id, quantitySold: qty })
            });
            if (!resp.ok) {
                const msg = await resp.text();
                alert('Sale failed: ' + msg);
            } else {
                await loadMedicines();
            }
        });

        gridBody.appendChild(tr);
    }
}

$('#searchBtn').addEventListener('click', loadMedicines);
$('#clearSearchBtn').addEventListener('click', () => { searchInput.value = ''; loadMedicines(); });

$('#addForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
        fullName: fd.get('fullName')?.toString().trim(),
        brand: fd.get('brand')?.toString().trim(),
        expiryDate: fd.get('expiryDate'),
        quantity: Number(fd.get('quantity')),
        price: Number(fd.get('price')),
        notes: fd.get('notes')?.toString() ?? ''
    };
    const resp = await fetch(API_BASE + '/api/medicines', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
    if (!resp.ok) {
        const msg = await resp.text();
        alert('Add failed: ' + msg);
        return;
    }
    e.currentTarget.reset();
    await loadMedicines();
});

loadMedicines();
