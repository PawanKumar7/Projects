﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using System.Text.Json;
using MyConsoleApp.Models;
using MyConsoleApp.Repositories;
using MyConsoleApp.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", p =>
        p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
});

builder.Services.Configure<JsonSerializerOptions>(opts =>
{
    opts.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    opts.WriteIndented = true;
});

builder.Services.AddSingleton<JsonDb>();
builder.Services.AddSingleton<MedicineRepository>();
builder.Services.AddSingleton<SalesRepository>();

var app = builder.Build();

app.Urls.Add("http://localhost:5059");

app.UseDefaultFiles();
app.UseStaticFiles();

app.UseCors("AllowAll");

app.MapGet("/api/medicines", async (HttpContext ctx, MedicineRepository repo) =>
{
    var search = ctx.Request.Query["search"].ToString()?.Trim();
    var items = await repo.GetAllAsync(search);
    return Results.Ok(items.Select(m => new
    {
        m.Id,
        fullName = m.FullName,
        expiryDate = m.ExpiryDate,
        quantity = m.Quantity,
        price = m.Price,
        brand = m.Brand
    }));
});

app.MapPost("/api/medicines", async (Medicine input, MedicineRepository repo) =>
{
    input.Id = Guid.Empty; 
    input.FullName = input.FullName?.Trim() ?? string.Empty;
    input.Brand = input.Brand?.Trim() ?? string.Empty;
    input.Notes = input.Notes ?? string.Empty;
    if (input.Price < 0) input.Price = 0;
    if (input.Quantity < 0) input.Quantity = 0;
    input.Price = Math.Round(input.Price, 2);

    var created = await repo.AddAsync(input);
    return Results.Created($"/api/medicines/{created.Id}", created);
});

// Sales API
app.MapPost("/api/sales", async (SalesRequest req, MedicineRepository mRepo, SalesRepository sRepo) =>
{
    if (req.QuantitySold <= 0) return Results.BadRequest("QuantitySold must be > 0");
    var result = await mRepo.RecordSaleAsync(req.MedicineId, req.QuantitySold);
    if (!result.ok) return Results.BadRequest(result.error);

    var sale = await sRepo.AddAsync(new SaleRecord
    {
        Id = Guid.NewGuid(),
        MedicineId = result.medicine!.Id,
        MedicineName = result.medicine.FullName,
        QuantitySold = req.QuantitySold,
        UnitPrice = result.medicine.Price,
        TotalPrice = Math.Round(result.medicine.Price * req.QuantitySold, 2),
        TimestampUtc = DateTime.UtcNow
    });

    return Results.Ok(sale);
});

app.MapFallbackToFile("/index.html");

app.Run();

record SalesRequest(Guid MedicineId, int QuantitySold);
