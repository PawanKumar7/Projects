﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace MyConsoleApp.Data;

public class JsonDb
{
    private readonly string _dataDir;
    private readonly SemaphoreSlim _lock = new(1, 1);
    private readonly JsonSerializerOptions _jsonOptions;

    public JsonDb(IHostEnvironment env, Microsoft.Extensions.Options.IOptions<JsonSerializerOptions> jsonOptions)
    {
        _dataDir = Path.Combine(env.ContentRootPath, "App_Data");
        Directory.CreateDirectory(_dataDir);
        _jsonOptions = jsonOptions.Value;
    }

    private string PathFor(string name) => System.IO.Path.Combine(_dataDir, name);

    public async Task<List<T>> ReadListAsync<T>(string fileName)
    {
        var path = PathFor(fileName);
        if (!File.Exists(path))
        {
            await File.WriteAllTextAsync(path, "[]");
            return new List<T>();
        }

        await _lock.WaitAsync();
        try
        {
            var json = await File.ReadAllTextAsync(path);
            var data = JsonSerializer.Deserialize<List<T>>(json, _jsonOptions) ?? new List<T>();
            return data;
        }
        finally
        {
            _lock.Release();
        }
    }

    public async Task WriteListAsync<T>(string fileName, List<T> items)
    {
        await _lock.WaitAsync();
        try
        {
            var json = JsonSerializer.Serialize(items, _jsonOptions);
            await File.WriteAllTextAsync(PathFor(fileName), json);
        }
        finally
        {
            _lock.Release();
        }
    }


}
