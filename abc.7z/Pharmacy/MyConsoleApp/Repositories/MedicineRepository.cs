﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyConsoleApp.Data;
using MyConsoleApp.Models;

namespace MyConsoleApp.Repositories;

public class MedicineRepository
{
    private readonly JsonDb _db;
    private const string FileName = "medicines.json";

    public MedicineRepository(JsonDb db)
    {
        _db = db;
    }

    public async Task<List<Medicine>> GetAllAsync(string? search)
    {
        var list = await _db.ReadListAsync<Medicine>(FileName);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var needle = search.Trim().ToLowerInvariant();
            list = list.Where(m => (m.FullName ?? string.Empty).ToLowerInvariant().Contains(needle)).ToList();
        }
        return list.OrderBy(m => m.FullName).ToList();
    }

    public async Task<Medicine> AddAsync(Medicine med)
    {
        var list = await _db.ReadListAsync<Medicine>(FileName);
        med.Id = Guid.NewGuid();
        med.Price = Math.Round(med.Price, 2);
        list.Add(med);
        await _db.WriteListAsync(FileName, list);
        return med;
    }

    public async Task<(bool ok, string? error, Medicine? medicine)> RecordSaleAsync(Guid medicineId, int qty)
    {
        var list = await _db.ReadListAsync<Medicine>(FileName);
        var med = list.FirstOrDefault(m => m.Id == medicineId);
        if (med == null) return (false, "Medicine not found", null);
        if (qty <= 0) return (false, "QuantitySold must be > 0", null);
        if (med.Quantity < qty) return (false, "Insufficient stock", null);

        med.Quantity -= qty;
        await _db.WriteListAsync(FileName, list);
        return (true, null, med);
    }
}
