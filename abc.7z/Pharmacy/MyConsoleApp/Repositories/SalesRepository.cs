﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyConsoleApp.Data;
using MyConsoleApp.Models;

namespace MyConsoleApp.Repositories;

public class SalesRepository
{
    private readonly JsonDb _db;
    private const string FileName = "sales.json";

    public SalesRepository(JsonDb db)
    {
        _db = db;
    }

    public async Task<SaleRecord> AddAsync(SaleRecord sale)
    {
        var list = await _db.ReadListAsync<SaleRecord>(FileName);
        list.Add(sale);
        await _db.WriteListAsync(FileName, list);
        return sale;
    }
}
